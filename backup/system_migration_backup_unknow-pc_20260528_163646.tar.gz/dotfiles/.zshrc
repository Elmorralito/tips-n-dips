export ZSH="$HOME/.oh-my-zsh"

export SHOW_FASTFETCH=1

ZSH_THEME="spaceship"

export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init --path)"

export MANPATH="/usr/local/man:$MANPATH"
export LANG=en_US.UTF-8

source "/home/notknown/.oh-my-zsh/custom/themes/spaceship.zsh-theme"

DISABLE_AUTO_UPDATE="false"
DISABLE_MAGIC_FUNCTIONS="true"
DISABLE_COMPFIX="true"

export PATH="$HOME/bin:$HOME/.local/bin:/usr/local/bin:$PATH"

export ZSH="$HOME/.oh-my-zsh"

export ZSH_THEME="spaceship"

plugins=(
	git
	pyenv
	docker
)

# --- Spaceship Prompt (https://github.com/spaceship-prompt/spaceship-prompt / Oh My Zsh) ---
# Prompt shell: spacing, async git/dir, newline before prompt for readability.
SPACESHIP_PROMPT_ASYNC=true
SPACESHIP_PROMPT_ADD_NEWLINE=true
SPACESHIP_PROMPT_SEPARATE_LINE=true
SPACESHIP_PROMPT_PREFIXES_SHOW=true
SPACESHIP_PROMPT_SUFFIXES_SHOW=true
SPACESHIP_PROMPT_FIRST_PREFIX_SHOW=false
SPACESHIP_PROMPT_DEFAULT_PREFIX="via "
SPACESHIP_PROMPT_DEFAULT_SUFFIX=" "

# Primary / secondary prompt glyph (vi-mode aware if you use vi mode)
SPACESHIP_CHAR_SYMBOL="⚡:\❯"
SPACESHIP_CHAR_SUFFIX=" "
SPACESHIP_CHAR_COLOR_SUCCESS="green"
SPACESHIP_CHAR_COLOR_FAILURE="red"

# Time (compact, 24h). Set false to skip one strftime per prompt (marginal gain).
SPACESHIP_TIME_SHOW=true
SPACESHIP_TIME_FORMAT="%D{%H:%M:%S}"
SPACESHIP_TIME_COLOR="242"
SPACESHIP_TIME_SUFFIX=" | "

# User: hide on your normal machine; show when root or SSH
SPACESHIP_USER_SHOW=needed
SPACESHIP_USER_COLOR="yellow"
SPACESHIP_USER_COLOR_ROOT="red"

# true = show when connected via SSH (default behavior)
SPACESHIP_HOST_SHOW=true
SPACESHIP_HOST_COLOR="blue"
SPACESHIP_HOST_COLOR_SSH="green"

# Directory: repo-relative path; TRUNC = how many folder names to keep from cwd upward (3 ⇒ parent + current + …)
SPACESHIP_DIR_SHOW=true
SPACESHIP_DIR_TRUNC=3
SPACESHIP_DIR_TRUNC_REPO=true
SPACESHIP_DIR_COLOR="green"

# Git: branch + concise status
SPACESHIP_GIT_SHOW=true
SPACESHIP_GIT_BRANCH_SHOW=true
SPACESHIP_GIT_STATUS_SHOW=true
SPACESHIP_GIT_BRANCH_COLOR="magenta"
SPACESHIP_GIT_STATUS_COLOR="red"

# Python toolchain (pyenv / python version — Spaceship uses the `python` section name)
SPACESHIP_PYTHON_SHOW=true
SPACESHIP_PYTHON_PREFIX="using "
SPACESHIP_PYTHON_SYMBOL="🐍 "
SPACESHIP_PYTHON_COLOR="yellow"

SPACESHIP_VENV_SHOW=true
SPACESHIP_VENV_PREFIX="- venv: "
SPACESHIP_VENV_SYMBOL="📦 "
SPACESHIP_VENV_COLOR="blue"

# Docker (shown when Dockerfile / compose files exist in tree — see Spaceship docker section docs)
SPACESHIP_DOCKER_SHOW=true
SPACESHIP_DOCKER_ASYNC=true
SPACESHIP_DOCKER_SYMBOL="🐳 "
SPACESHIP_DOCKER_COLOR="cyan"
SPACESHIP_DOCKER_VERBOSE=false
SPACESHIP_DOCKER_CONTEXT_SHOW=true
SPACESHIP_DOCKER_CONTEXT_ASYNC=true

# Long commands & failures (helps when something hangs or exits non-zero)
SPACESHIP_EXEC_TIME_SHOW=true
SPACESHIP_EXEC_TIME_ELAPSED=2
SPACESHIP_EXEC_TIME_COLOR="yellow"

SPACESHIP_PROMPT_ORDER=(
	time
	user
	host
	dir
	git
	line_sep
	pyenv
	venv
	docker
	line_sep
	exec_time
	jobs
	exit_code
	char
)
# Set list of themes to pick from when loading at random
# Setting this variable when ZSH_THEME=random will cause zsh to load
# a theme from this variable instead of looking in $ZSH/themes/
# If set to an empty array, this variable will have no effect.
# ZSH_THEME_RANDOM_CANDIDATES=( "robbyrussell" "agnoster" )

# See https://github.com/ohmyzsh/ohmyzsh/wiki/Themes
# Uncomment the following line to use case-sensitive completion.
# CASE_SENSITIVE="true"

# Uncomment the following line to use hyphen-insensitive completion.
# Case-sensitive completion must be off. _ and - will be interchangeable.
# HYPHEN_INSENSITIVE="true"

# Oh My Zsh update policy is set near `plugins` (reminder + 13-day frequency).
# To change it, edit that block or uncomment one of:

# Uncomment the following line if pasting URLs and other text is messed up.
DISABLE_MAGIC_FUNCTIONS="true"

# Uncomment the following line to disable colors in ls.
# DISABLE_LS_COLORS="true"

# Uncomment the following line to disable auto-setting terminal title.
# DISABLE_AUTO_TITLE="true"

# Uncomment the following line to enable command auto-correction.
# ENABLE_CORRECTION="true"

# Uncomment the following line to display red dots whilst waiting for completion.
# You can also set it to another string to have that shown instead of the default red dots.
# e.g. COMPLETION_WAITING_DOTS="%F{yellow}waiting...%f"
# Caution: this setting can cause issues with multiline prompts in zsh < 5.7.1 (see #5765)
COMPLETION_WAITING_DOTS="true"

# Uncomment the following line if you want to disable marking untracked files
# under VCS as dirty. This makes repository status check for large repositories
# much, much faster.
# DISABLE_UNTRACKED_FILES_DIRTY="true"

# Uncomment the following line if you want to change the command execution time
# stamp shown in the history command output.
# You can set one of the optional three formats:
# "mm/dd/yyyy"|"dd.mm.yyyy"|"yyyy-mm-dd"
# or set a custom format using the strftime function format specifications,
# see 'man strftime' for details.
HIST_STAMPS="yyyy-mm-dd"

# Which plugins would you like to load?
# Standard plugins can be found in $ZSH/plugins/
# Custom plugins may be added to $ZSH_CUSTOM/plugins/
# Example format: plugins=(rails git textmate ruby lighthouse)
# Add wisely, as too many plugins slow down shell startup.
#
# Recommended core (keep):
#   git     — aliases & functions for daily Git use
#   pyenv   — loads pyenv (+ pyenv-virtualenv if present); you use pyenv
#   poetry  — Poetry completions + pad/pinst/… aliases
#   docker  — Docker CLI completions (Spaceship shows 🐳 when in Docker project dirs)
#
# Dropped by default (not “wrong”, just redundant or conditional):
#   virtualenv — only supplies virtualenv_prompt_info(); Spaceship already has venv section
#   virtualenvwrapper — needs pip-installed virtualenvwrapper; overlaps Poetry/pyenv; auto-cd activate can surprise
#   autojump — useless unless `brew install autojump` (or similar); consider zoxide + zsh-z plugin instead
#   pip — nice pip tab-completion; add back if you still run raw `pip` often
#   python — py/pyclean/mkv/vrun aliases; add back if you use them (Poetry covers most project flows)

# Oh My Zsh: lighter than default update checks (still get reminders every N days).
zstyle ':omz:update' mode reminder
zstyle ':omz:update' frequency 13

bindkey -r "^L"
bindkey -r "^P"
bindkey -r "\esc c"
bindkey -r "^T"

source $ZSH/oh-my-zsh.sh

# Git: fewer lock files / slightly snappier status in huge repos (safe for local dev).
export GIT_OPTIONAL_LOCKS=0

# User configuration
export MANPATH="/usr/local/man:$MANPATH"

# You may need to manually set your language environment
export LANG=en_US.UTF-8


# Compilation flags
# export ARCHFLAGS="-arch $(uname -m)"

# Set personal aliases, overriding those provided by Oh My Zsh libs,
# plugins, and themes. Aliases can be placed here, though Oh My Zsh
# users are encouraged to define aliases within a top-level file in
# the $ZSH_CUSTOM folder, with .zsh extension. Examples:
# - $ZSH_CUSTOM/aliases.zsh
# - $ZSH_CUSTOM/macos.zsh
# For a full list of active aliases, run `alias`.
#
# Example aliases
# alias zshconfig="mate ~/.zshrc"
# alias ohmyzsh="mate ~/.oh-my-zsh"

[ -f ~/.zsh_aliases ] && source ~/.zsh_aliases

# SSH agent once at shell startup (precmd used to run a check before *every* command).

if [[ -z "$SSH_AUTH_SOCK" ]] && command -v ssh-agent >/dev/null; then
  eval "$(ssh-agent -s)" >/dev/null
fi

export PATH="/root/.local/bin:/usr/local/bin:$PATH"

[[ "${SHOW_FASTFETCH:-}" == "1" ]] && command -v fastfetch >/dev/null && fastfetch
